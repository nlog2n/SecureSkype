﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Examples
{
    public class Program
    {
        public static void Main()
        {
            //RHTest.Run();
            LHTest.Run();

            Console.ReadLine();
        }
    }
}
